package LabC;

/**
 * An interface for the ADT list.
 * The user can only access the beginning or ending elements 
 * of a list, not any elements from the middle of the list
 * 
 * @author Faustina Nyaung
 */

public class EntryWayList<T> implements EntryWayListInterface<T>{	

	private T[] list;
	private int numberOfEntries;
	private static final int DEFAULT_CAPACITY = 25;
	private static final int MAX_CAPACITY = 10000;	
	
	public EntryWayList() {
		this(DEFAULT_CAPACITY);
	} // end default constructor

	public EntryWayList(int initialCapacity) {
		// Is initialCapacity too small?
		if (initialCapacity < DEFAULT_CAPACITY){
			initialCapacity = DEFAULT_CAPACITY;
		}else if(initialCapacity > DEFAULT_CAPACITY){
			throw new IndexOutOfBoundsException(
					"Attempt to create a list whose capacity exceeds allowed maximum.");
		}
		// The cast is safe because the new array contains null entries
				@SuppressWarnings("unchecked")
				T[] tempList = (T[]) new Object[initialCapacity];
				list = tempList;
				numberOfEntries = 0;
	} // end constructor
	
	/** Inserts the entry at a the beginning of the list.
     *  Entries (if any) originally in the list 
     *  are at the next lower position within the list,
     *  and the list's size increases by 1.
     *  @param newEntry  The object that is the desired entry.
     *  @return  True if the insertion is successful, 
     *           False if the insertion fails. 
     */
	public boolean insertHead(T newEntry){
		boolean insertion = false;
		//If the list is not empty and is less than default capacity
		if(numberOfEntries < MAX_CAPACITY){
			//moves all objects down by 1 to make space in [0].
			for(int index = numberOfEntries - 1; index >= 0; index--){ 
				list[index + 1] = list[index]; 
			}
			list[0] = newEntry;	
			numberOfEntries++;
			insertion = true;
		}
		return insertion;
	}

	
	/** Inserts the entry at a the end of the list.
	 *  Other entries (if any) currently in the list are unaffected.
	 *  The list's size increases by 1.
	 *  @param newEntry  The object that is the desired entry.
	 *  @return  True if the insertion is successful, 
	 *           False if the insertion fails. 
	 */
	public boolean insertTail(T newEntry){
		boolean insertion = false;
		//If the list is not empty and is less than default capacity
		if(numberOfEntries < MAX_CAPACITY){
			list[numberOfEntries] = newEntry;	
			numberOfEntries++;
			insertion = true;
		}
		return insertion;
	}

	/** Deletes the entry at the top of the list.
	 *  Other entries' positions are moved up by 1. 
	 *  The list's size is decreased by 1.
	 *  @return  the object that has been deleted. 
	 *           If no object was deleted, (list is empty), return null. 
	 */
	public T deleteHead(){
		T deletedHead;
		//If the list is not empty 
		if(numberOfEntries > 0){
			deletedHead = list[0];
			//moves all objects down by 1 to remove the first array.
			for(int index = 0; index < numberOfEntries - 1; index++){ 
				list[index] = list[index + 1]; 
			}
			list[numberOfEntries - 1] = null; //the last array is null.
			numberOfEntries--;
		}else{ //if the list is empty
			deletedHead = null;
		}
		return deletedHead;
	}

	/** Deletes the element at the end of the list.
	 *  Other entries (if any) currently in the list are unaffected.
	 *  The list's size is decreased by 1.
	 *  @return  the object that has been deleted.
	 *  If no object was deleted, (list is empty), return null.
	 */
	public T deleteTail(){
		T deletedTail;
		//If the list is not empty 
		if(numberOfEntries > 0){
			deletedTail = list[numberOfEntries - 1];
			list[numberOfEntries - 1] = null;
			numberOfEntries--;
		}else{ //if the list is empty return null
			deletedTail = null;
		}
		return deletedTail;
	}

	/** Displays all of the entries in the list*/
	public void display() {
		System.out.print("[");
		for (int index = 0; index < numberOfEntries; index++) {
			System.out.print(list[index]);
			if(index < numberOfEntries -1){
				System.out.print(", ");	
			}
		}
		System.out.println("]");
	}

	/** Locates where the entry's position are.
	 * @param anEntry  The object that is the desired entry.
	 * @return  the last position of the entry that was found.
	 *          if anEntry is not found, then return -1. 
	 */
	public int contains(T anEntry){
		int entryPosition = -1;
		for(int index = 0; index < numberOfEntries; index++){
			if(anEntry.equals(list[index])){
				entryPosition = index;
			}
		}
		return entryPosition;
	}

	/** Determines whether this list is empty.
	 * @return  True if the list is empty, or false if not.
	 */
	public boolean isEmpty(){
		return numberOfEntries == 0;
	}

	/**
	 *  Determines whether this list is full.
	 *  @return  True if the list is full, or false if it is not. 
	 */
	public boolean isFull(){
		if(numberOfEntries == MAX_CAPACITY){
			return true;
		}else{
			return false;
		}
	}

} // end EntryWayListInterface