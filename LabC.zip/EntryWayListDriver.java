package LabC;

/**
 * Tests the EntryWayList class
 * 
 * @author Faustina Nyaung
 */
public class EntryWayListDriver {
	public static void main(String[] args) {
		
		// setting up EntryWayList to test
		System.out.println("\nTESTING LIST");
		EntryWayList<String> produceList = new EntryWayList<String>();
		System.out.println("Should display  []:"); //display an empty list
		System.out.print("\t\t");
		produceList.display();
		
		/**
		 * Tests the insertHead, insertTail, and display method:
		 */
		//add five entries to the list
		produceList.insertHead("banana");
		produceList.insertTail("date");
		produceList.insertHead("grape");
		produceList.insertTail("eggplant");
		produceList.insertHead("jicama");
		System.out.println("Should display  [jicama, grape, banana, date, eggplant]:");
		System.out.print("\t\t");
		produceList.display(); //display the list
		System.out.println();
		
		/**
		 * Tests the contains method:
		 */
		System.out.println("The position of 'banana' is 2: " + produceList.contains("banana"));
		System.out.println("The position of 'date' is 3: " + produceList.contains("date"));
		System.out.println("The position of 'pear' is -1: " + produceList.contains("pear"));
		System.out.println();
		
		/**
		 * Tests the deleteHead method: remove the first entry
		 */
		produceList.deleteHead();
		System.out.println("Should display  [grape, banana, date, eggplant]:");
		System.out.print("\t\t");
		produceList.display();
		System.out.println();
		
		/**
		 * Tests the deleteTail method: remove the last entry
		 */
		produceList.deleteTail();
		System.out.println("Should display  [grape, banana, date]:");
		System.out.print("\t\t");
		produceList.display();
		System.out.println();
		
		/**
		 * Tests the isFull method:
		 */
		produceList.display();
		System.out.println("Is the produce List full? false: " + produceList.isFull());
		
		/**
		 * Tests the isEmpty method: removed the last three elements in the list
		 */
		produceList.deleteHead(); // deletes grape
		produceList.deleteTail(); // deletes date
		produceList.deleteHead(); // deletes banana (the list becomes empty)
		produceList.display();
		System.out.println("Is the produce List empty? true: " + produceList.isEmpty());
		
		/**
		 * Try to remove an element from the empty list
		 */
		produceList.deleteHead();
		System.out.println("Is the produce List still empty? true: " + produceList.isEmpty());		
	}

}

/**
 * 
OUTPUT: 

TESTING LIST
Should display  []:
		[]
Should display  [jicama, grape, banana, date, eggplant]:
		[jicama, grape, banana, date, eggplant]

The position of 'banana' is 2: 2
The position of 'date' is 3: 3
The position of 'pear' is -1: -1

Should display  [grape, banana, date, eggplant]:
		[grape, banana, date, eggplant]

Should display  [grape, banana, date]:
		[grape, banana, date]

[grape, banana, date]
Is the produce List full? false: false
[]
Is the produce List empty? true: true
Is the produce List still empty? true: true
*/
