package LabC;

/** An interface for the ADT list.
The user can only access the beginning or ending elements 
of a list, not any elements from the middle of the list

@author Faustina Nyaung
*/

public interface EntryWayListInterface<T> {

	
/** Inserts the entry at a the beginning of the list.
 *  Entries (if any) originally in the list 
 *  are at the next lower position within the list,
 *  and the list's size increases by 1.
 *  @param newEntry  The object that is the desired entry.
 *  @return  True if the insertion is successful, 
 *           False if the insertion fails. 
 */
public boolean insertHead(T newEntry);

/** Inserts the entry at a the end of the list.
 *  Other entries (if any) currently in the list are unaffected.
 *  The list's size increases by 1.
 *  @param newEntry  The object that is the desired entry.
 *  @return  True if the insertion is successful, 
 *           False if the insertion fails. 
 */
public boolean insertTail(T newEntry);

/** Deletes the entry at the top of the list.
 *  Other entries' positions are moved up by 1. 
 *  The list's size is decreased by 1.
 *  @return  the object that has been deleted. 
 *           If no object was deleted, (list is empty), return null. 
 */
public T deleteHead();

/** Deletes the element at the end of the list.
 *  Other entries (if any) currently in the list are unaffected.
 *  The list's size is decreased by 1.
 *  @return  the object that has been deleted.
 *  If no object was deleted, (list is empty), return null.
 */
public T deleteTail();

/** Displays all of the entries in the list*/
public void display();

/** Locates where the entry's position are.
 * @param anEntry  The object that is the desired entry.
 * @return  the last position of the entry that was found.
 *          if anEntry is not found, then return -1. 
 */
public int contains(T anEntry);

/** Determines whether this list is empty.
 * @return  True if the list is empty, or false if not.
 */
public boolean isEmpty();

/**
 *  Determines whether this list is full.
 *  @return  True if the list is full, or false if it is not. 
 */
public boolean isFull();

} // end EntryWayListInterface